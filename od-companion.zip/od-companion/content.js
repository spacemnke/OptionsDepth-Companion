// ================================================================
// OD COMPANION — Plain-English Trading Insights from OptionDepth
// ================================================================
(function () {
  "use strict";

  let previousAnalysis = null;
  let refreshTimer = null;
  let panel = null;
  let isCollapsed = false;
  let manualPrice = null;
  let autoRefreshSeconds = 30;
  let changeLog = [];           // persistent change history
  const CHANGE_TTL_MS = 300000; // keep changes for 5 minutes

  const ZONE_PROXIMITY = 10;
  const MIN_GEX_SIGNIFICANCE = 1.0;
  const PANEL_ID = "od-companion-panel";

  // ================================================================
  //  DATA EXTRACTION
  // ================================================================

  function extractDepthTable() {
    const table = document.querySelector("table");
    if (!table) return null;
    const rows = table.querySelectorAll("tr");
    if (rows.length < 3) return null;

    const headerCells = rows[0].querySelectorAll("th");
    const headers = Array.from(headerCells).map((h) => h.textContent.trim());

    const today = new Date();
    const todayStr = today.toISOString().split("T")[0];
    let odteIdx = -1;
    for (let i = 1; i < headers.length; i++) {
      if (headers[i].startsWith(todayStr)) { odteIdx = i; break; }
    }
    if (odteIdx === -1) odteIdx = 1;

    const strikes = [];
    for (let r = 1; r < rows.length; r++) {
      const cells = rows[r].querySelectorAll("td");
      if (cells.length < 3) continue;
      const strike = parseFloat(cells[0].textContent.trim());
      if (isNaN(strike)) continue;
      let odteGEX = 0, totalGEX = 0;
      const perExp = [];
      for (let c = 1; c < cells.length - 1; c++) {
        const v = parseFloat(cells[c].textContent.trim());
        if (!isNaN(v)) { totalGEX += v; perExp.push(v); if (c === odteIdx) odteGEX = v; }
      }
      strikes.push({ strike, odteGEX, totalGEX, perExp });
    }
    strikes.sort((a, b) => b.strike - a.strike);
    return { headers, strikes, odteIdx, time: new Date().toLocaleTimeString() };
  }

  function detectCurrentPrice(strikes) {
    if (manualPrice) return manualPrice;

    // Strategy 1: Find the highlighted strike row in the Depth View Table.
    // OptionDepth highlights the row nearest current price with a unique bg.
    const table = document.querySelector("table");
    if (table) {
      const rows = table.querySelectorAll("tr");
      const bgCounts = {};
      const strikeBGs = [];
      for (let r = 1; r < rows.length; r++) {
        const cells = rows[r].querySelectorAll("td");
        if (cells.length < 2) continue;
        const strike = parseFloat(cells[0].textContent.trim());
        if (isNaN(strike)) continue;
        const bg = window.getComputedStyle(cells[0]).backgroundColor;
        bgCounts[bg] = (bgCounts[bg] || 0) + 1;
        strikeBGs.push({ strike, bg });
      }
      // The highlighted row has a unique background (only 1-2 rows with it)
      for (const { strike, bg } of strikeBGs) {
        if (bgCounts[bg] <= 2 && Object.keys(bgCounts).length > 1) {
          return strike;
        }
      }
    }

    // Strategy 2: Look for price-like text in DOM elements
    const candidates = document.querySelectorAll('span, div, [class*="price"], [class*="last"], [class*="current"], [class*="axis"], [class*="cursor"]');
    for (const el of candidates) {
      if (el.closest("#" + PANEL_ID)) continue;
      if (el.children.length > 2) continue;
      const t = el.textContent.trim();
      if (/^\d{4}\.\d{1,2}$/.test(t)) {
        const v = parseFloat(t);
        if (v >= 5000 && v <= 10000) return v;
      }
    }

    // Strategy 3: Fallback to midpoint of visible range
    if (strikes.length >= 2) {
      return Math.round((strikes[0].strike + strikes[strikes.length - 1].strike) / 2);
    }
    return null;
  }

  // ================================================================
  //  ANALYSIS ENGINE
  // ================================================================

  function findZones(candidates) {
    const sorted = [...candidates]
      .filter((s) => Math.abs(s.totalGEX) >= MIN_GEX_SIGNIFICANCE * 0.3)
      .sort((a, b) => Math.abs(b.totalGEX) - Math.abs(a.totalGEX));
    const zones = [], used = new Set();
    for (const c of sorted) {
      if (used.has(c.strike)) continue;
      const cluster = candidates.filter(
        (s) => Math.abs(s.strike - c.strike) <= ZONE_PROXIMITY && !used.has(s.strike)
      );
      const lo = Math.min(...cluster.map((s) => s.strike));
      const hi = Math.max(...cluster.map((s) => s.strike));
      const strength = cluster.reduce((sum, s) => sum + s.totalGEX, 0);
      zones.push({
        lo, hi,
        label: lo === hi ? `${lo}` : `${lo}\u2013${hi}`,
        strength: +strength.toFixed(2),
        count: cluster.length,
      });
      cluster.forEach((s) => used.add(s.strike));
      if (zones.length >= 3) break;
    }
    return zones;
  }

  function analyze(data) {
    if (!data || data.strikes.length === 0) return null;
    const { strikes } = data;
    const price = detectCurrentPrice(strikes);
    if (!price) return null;

    const above = strikes.filter((s) => s.strike > price);
    const below = strikes.filter((s) => s.strike <= price);

    // Regime calc
    let posGEX = 0, negGEX = 0, posOdte = 0, negOdte = 0;
    strikes.forEach((s) => {
      if (s.totalGEX > 0) posGEX += s.totalGEX; else negGEX += s.totalGEX;
      if (s.odteGEX > 0) posOdte += s.odteGEX; else negOdte += s.odteGEX;
    });
    const absTotal = posGEX + Math.abs(negGEX);
    const posRatio = absTotal > 0 ? posGEX / absTotal : 0.5;
    const totalAbsGEX = strikes.reduce((s, x) => s + Math.abs(x.totalGEX), 0);

    // Directional lean — weight of positioning above vs below
    const gexAbove = above.reduce((s, x) => s + x.totalGEX, 0);
    const gexBelow = below.reduce((s, x) => s + x.totalGEX, 0);
    const absAbove = above.reduce((s, x) => s + Math.abs(x.totalGEX), 0);
    const absBelow = below.reduce((s, x) => s + Math.abs(x.totalGEX), 0);

    // ── Attributes ──
    let gammaRegime, gammaRegimeColor;
    if (posRatio > 0.62) { gammaRegime = "Positive"; gammaRegimeColor = "green"; }
    else if (posRatio < 0.38) { gammaRegime = "Negative"; gammaRegimeColor = "red"; }
    else { gammaRegime = "Mixed"; gammaRegimeColor = "amber"; }

    let flowDirection, flowDirectionColor;
    if (posRatio > 0.55) { flowDirection = "Supportive"; flowDirectionColor = "cyan"; }
    else if (posRatio < 0.45) { flowDirection = "Suppressive"; flowDirectionColor = "red"; }
    else { flowDirection = "Neutral"; flowDirectionColor = "dim"; }

    let conviction, convictionColor;
    if (totalAbsGEX > 40) { conviction = "High"; convictionColor = "amber"; }
    else if (totalAbsGEX > 15) { conviction = "Moderate"; convictionColor = "cyan"; }
    else { conviction = "Low"; convictionColor = "dim"; }

    let dealerBehavior, dealerColor;
    if (posRatio > 0.55) { dealerBehavior = "Absorbing moves"; dealerColor = "green"; }
    else if (posRatio < 0.45) { dealerBehavior = "Hedging with price"; dealerColor = "cyan"; }
    else { dealerBehavior = "Mixed hedging"; dealerColor = "amber"; }

    let directionalBias, biasColor;
    if (absAbove > 0 && absBelow > 0) {
      const biasRatio = absAbove / (absAbove + absBelow);
      if (biasRatio > 0.58) { directionalBias = "Upside capped"; biasColor = "red"; }
      else if (biasRatio < 0.42) { directionalBias = "Downside cushioned"; biasColor = "green"; }
      else { directionalBias = "Balanced"; biasColor = "cyan"; }
    } else {
      directionalBias = "Insufficient data"; biasColor = "dim";
    }

    // ── Regime label ──
    let regime, regimeEmoji;
    if (posRatio > 0.62) { regime = "RANGE-BOUND"; regimeEmoji = "\u2194"; }
    else if (posRatio < 0.38) { regime = "TRENDING"; regimeEmoji = "\u2192"; }
    else { regime = "TRANSITIONAL"; regimeEmoji = "\u27F3"; }

    // ── Key Levels ──
    const supportZones = findZones(below.filter((s) => s.totalGEX > 0));
    const resistanceZones = findZones(above.filter((s) => s.totalGEX > 0));
    const byAbsGEX = [...strikes].sort((a, b) => Math.abs(b.totalGEX) - Math.abs(a.totalGEX));
    const magnetStrike = byAbsGEX.length > 0 ? { strike: byAbsGEX[0].strike, gex: +byAbsGEX[0].totalGEX.toFixed(2) } : null;

    let triggerLevel = null;
    const nearPrice = strikes.filter((s) => Math.abs(s.strike - price) <= 40).sort((a, b) => b.strike - a.strike);
    for (let i = 0; i < nearPrice.length - 1; i++) {
      const a = nearPrice[i], b = nearPrice[i + 1];
      if ((a.totalGEX >= 0 && b.totalGEX < 0) || (a.totalGEX < 0 && b.totalGEX >= 0)) {
        triggerLevel = Math.round((a.strike + b.strike) / 2); break;
      }
    }

    const polrAbove = above.filter((s) => s.totalGEX < -0.5).sort((a, b) => a.strike - b.strike);
    const polrBelow = below.filter((s) => s.totalGEX < -0.5).sort((a, b) => b.strike - a.strike);

    // ── Guidance (hybrid: regime top-line + positional callouts) ──
    const guidanceLines = buildGuidance(price, regime, posRatio, supportZones, resistanceZones, magnetStrike, triggerLevel, polrAbove, polrBelow);

    // ── Scenarios ──
    const sup1 = supportZones[0], sup2 = supportZones[1], res1 = resistanceZones[0];
    let holdScenario = "", breakScenario = "", ceilingScenario = "";

    if (sup1 && res1) holdScenario = `If ${sup1.label} holds \u2192 look for move toward ${res1.label}`;
    else if (sup1) holdScenario = `If ${sup1.label} holds \u2192 expect range-bound action above`;
    if (sup1 && sup2) breakScenario = `If ${sup1.label} breaks \u2192 watch ${sup2.label} as next floor`;
    else if (sup1 && polrBelow.length > 0) breakScenario = `If ${sup1.label} breaks \u2192 fast move toward ${polrBelow[0].strike} likely`;
    else if (sup1) breakScenario = `If ${sup1.label} breaks \u2192 acceleration lower, look for new support`;
    if (res1) {
      const res2 = resistanceZones[1];
      if (polrAbove.length > 0 && polrAbove[0].strike > (res1.hi || res1.lo))
        ceilingScenario = `Above ${res1.label} \u2192 opens path to ${polrAbove[0].strike}+`;
      else if (res2 && res2.lo > res1.hi)
        ceilingScenario = `Above ${res1.label} \u2192 next ceiling at ${res2.label}`;
      else
        ceilingScenario = `Above ${res1.label} \u2192 room to run higher`;
    }

    // ── Environment Summary (prose paragraph) ──
    const summary = buildSummary(regime, posRatio, totalAbsGEX, flowDirection, directionalBias, supportZones, resistanceZones);

    // ── Changes (accumulated over time) ──
    const now = Date.now();
    // Prune old entries
    changeLog = changeLog.filter((c) => now - c.ts < CHANGE_TTL_MS);

    if (previousAnalysis) {
      const prev = previousAnalysis;
      const timeLabel = new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
      if (prev.regime !== regime)
        changeLog.push({ ts: now, text: `${timeLabel} \u2014 Regime shifted \u2192 ${regime.toLowerCase()}` });
      if (sup1 && prev.supportZones?.[0]) {
        if (sup1.strength > prev.supportZones[0].strength * 1.15)
          changeLog.push({ ts: now, text: `${timeLabel} \u2014 Support strengthening` });
        else if (sup1.strength < prev.supportZones[0].strength * 0.85)
          changeLog.push({ ts: now, text: `${timeLabel} \u2014 Support weakening` });
      }
      if (res1 && prev.resistanceZones?.[0]) {
        if (res1.strength > prev.resistanceZones[0].strength * 1.15)
          changeLog.push({ ts: now, text: `${timeLabel} \u2014 Resistance strengthening` });
        else if (res1.strength < prev.resistanceZones[0].strength * 0.85)
          changeLog.push({ ts: now, text: `${timeLabel} \u2014 Resistance weakening` });
      }
      if (sup1 && prev.supportZones?.[0]) {
        const drift = sup1.lo - prev.supportZones[0].lo;
        if (drift >= 10) changeLog.push({ ts: now, text: `${timeLabel} \u2014 Levels drifting higher` });
        else if (drift <= -10) changeLog.push({ ts: now, text: `${timeLabel} \u2014 Levels drifting lower` });
      }
      if (prev.price && Math.abs(price - prev.price) >= 5)
        changeLog.push({ ts: now, text: `${timeLabel} \u2014 Price moved ${price > prev.price ? "up" : "down"} ${Math.abs(price - prev.price).toFixed(0)} pts` });
    }
    const changes = changeLog.length > 0
      ? changeLog.slice(-6).map((c) => c.text)
      : ["Watching for changes\u2026"];

    const result = {
      timestamp: data.time, price, priceIsManual: !!manualPrice,
      regime, regimeEmoji, summary,
      attributes: [
        { label: "Gamma regime", value: gammaRegime, color: gammaRegimeColor },
        { label: "Charm influence", value: flowDirection, color: flowDirectionColor },
        { label: "Volatility", value: conviction, color: convictionColor },
        { label: "Dealer behavior", value: dealerBehavior, color: dealerColor },
        { label: "Directional bias", value: directionalBias, color: biasColor },
      ],
      supportZones, resistanceZones, magnetStrike, triggerLevel,
      guidanceLines,
      holdScenario, breakScenario, ceilingScenario,
      changes,
      posRatio: +posRatio.toFixed(2), totalAbsGEX: +totalAbsGEX.toFixed(1), strikeCount: strikes.length,
    };
    previousAnalysis = result;
    return result;
  }

  // ================================================================
  //  PROSE GENERATOR
  // ================================================================

  function buildSummary(regime, posRatio, totalAbsGEX, flow, bias, support, resistance) {
    const parts = [];

    // Sentence 1 — regime
    if (regime === "RANGE-BOUND") {
      parts.push("We're in a stable environment where levels are sticky and price tends to mean-revert.");
    } else if (regime === "TRENDING") {
      parts.push("We're in an accelerating environment where moves are more likely to follow through.");
    } else {
      parts.push("We're in a transitional environment with no dominant force controlling price.");
    }

    // Sentence 2 — flow
    if (posRatio > 0.6) {
      parts.push("Flows are supportive, helping cushion dips and limit downside.");
    } else if (posRatio < 0.4) {
      parts.push("Flows are suppressive, creating headwinds for rallies and adding fuel to selloffs.");
    } else {
      parts.push("Flows are mixed, with neither buyers nor sellers in clear control.");
    }

    // Sentence 3 — conviction/density
    if (totalAbsGEX > 40) {
      parts.push("Positioning is heavy \u2014 expect levels to be respected.");
    } else if (totalAbsGEX < 10) {
      parts.push("Positioning is light \u2014 price has room to move freely.");
    }

    // Sentence 4 — expectation
    if (regime === "RANGE-BOUND") {
      parts.push("Expect chop. Fade the edges.");
    } else if (regime === "TRENDING") {
      if (posRatio < 0.4) parts.push("Don't fight the move. Let runners run.");
      else parts.push("Lean with the trend but respect the levels.");
    } else {
      parts.push("Stay patient. Wait for one side to take control.");
    }

    return parts.join(" ");
  }

  // ================================================================
  //  POSITIONAL GUIDANCE
  // ================================================================

  function buildGuidance(price, regime, posRatio, support, resistance, magnet, trigger, polrAbove, polrBelow) {
    const lines = [];
    const sup1 = support[0], res1 = resistance[0];

    // ── Top line: regime read ──
    if (posRatio > 0.55) {
      lines.push({ text: "Stable structure \u2014 fade moves into levels, don\u2019t chase.", type: "regime" });
    } else if (posRatio < 0.45) {
      lines.push({ text: "Volatile structure \u2014 moves follow through. Go with momentum.", type: "regime" });
    } else {
      lines.push({ text: "Mixed structure \u2014 no edge right now. Be selective.", type: "regime" });
    }

    // ── Positional lines based on price location ──
    if (sup1 && res1) {
      const distSup = price - (sup1.hi || sup1.lo);
      const distRes = (res1.lo || res1.hi) - price;

      if (distSup >= 0 && distSup <= 10) {
        // Near/at support
        if (posRatio > 0.45) {
          lines.push({ text: `Testing ${sup1.label} support. If it holds, long entry zone. Tight stop below.`, type: "support" });
        } else {
          lines.push({ text: `At ${sup1.label} support but environment is weak \u2014 likely breaks. Don\u2019t catch the knife.`, type: "warning" });
        }
      } else if (distRes >= 0 && distRes <= 10) {
        // Near/at resistance
        if (posRatio > 0.55) {
          lines.push({ text: `Pressing into ${res1.label} resistance. Fade if it stalls \u2014 sell zone.`, type: "resistance" });
        } else {
          lines.push({ text: `At ${res1.label} resistance. Could break through here \u2014 don\u2019t short blindly.`, type: "warning" });
        }
      } else if (distSup > 20 && distRes > 20) {
        // Mid-range / no man's land
        lines.push({ text: `Mid-range between ${sup1.label} and ${res1.label}. No edge \u2014 wait for a level to be tested.`, type: "neutral" });
      } else if (distRes < distSup) {
        // Drifting toward resistance
        lines.push({ text: `Approaching ${res1.label} resistance. Watch for rejection or breakout.`, type: "approach" });
      } else {
        // Hovering above support
        lines.push({ text: `Above ${sup1.label} support. Watch for a hold to go long or a break to step aside.`, type: "approach" });
      }
    } else if (sup1 && !res1) {
      lines.push({ text: `Only support visible at ${sup1.label}. No clear ceiling \u2014 upside is open.`, type: "approach" });
    } else if (!sup1 && res1) {
      lines.push({ text: `Only resistance visible at ${res1.label}. No clear floor \u2014 be careful on longs.`, type: "warning" });
    }

    // ── Flip level context if nearby ──
    if (trigger && Math.abs(price - trigger) <= 15) {
      lines.push({ text: `Near flip level at ${trigger} \u2014 behavior changes above vs below this line.`, type: "flip" });
    }

    return lines;
  }

  // ================================================================
  //  UI
  // ================================================================

  function createPanel() {
    if (document.getElementById(PANEL_ID)) return;

    // Inject retro terminal font
    if (!document.getElementById("odc-retro-font")) {
      const link = document.createElement("link");
      link.id = "odc-retro-font";
      link.rel = "stylesheet";
      link.href = "https://fonts.googleapis.com/css2?family=Share+Tech+Mono&display=swap";
      document.head.appendChild(link);
    }

    panel = document.createElement("div");
    panel.id = PANEL_ID;
    panel.innerHTML = `
      <div class="odc-header" id="odc-drag-handle">
        <div class="odc-header-top">
          <div class="odc-title-row">
            <span class="odc-title">OD Companion</span>
            <span class="odc-status-dot"></span>
          </div>
          <div class="odc-header-actions">
            <button class="odc-btn odc-refresh-btn" title="Refresh">\u27F2</button>
            <button class="odc-btn odc-collapse-btn" title="Collapse">\u2212</button>
          </div>
        </div>
        <div class="odc-divider"></div>
        <div class="odc-ticker-row">
          <span class="odc-ticker">SPX</span>
          <span class="odc-ticker-sub">S&P 500 Index</span>
        </div>
        <div class="odc-price-row">
          <span class="odc-price-value"></span>
          <span class="odc-price-status"></span>
        </div>
      </div>
      <div class="odc-body">
        <div class="odc-loading">Reading OptionDepth data\u2026</div>
      </div>
      <div class="odc-footer">
        <label class="odc-price-override">
          Price: <input type="number" class="odc-price-input" placeholder="auto" step="1" />
        </label>
        <span class="odc-auto-label"></span>
      </div>
    `;
    document.body.appendChild(panel);

    panel.querySelector(".odc-collapse-btn").addEventListener("click", () => {
      isCollapsed = !isCollapsed;
      panel.classList.toggle("odc-collapsed", isCollapsed);
      panel.querySelector(".odc-collapse-btn").textContent = isCollapsed ? "+" : "\u2212";
    });
    panel.querySelector(".odc-refresh-btn").addEventListener("click", refreshNow);
    panel.querySelector(".odc-price-input").addEventListener("change", (e) => {
      const v = parseFloat(e.target.value);
      manualPrice = isNaN(v) ? null : v;
      refreshNow();
    });
  }

  function strengthBar(val) {
    const pct = Math.min(100, (Math.abs(val) / 20) * 100);
    const color = val > 0 ? "var(--odc-green)" : "var(--odc-red)";
    return `<span class="odc-strength-bar"><span class="odc-strength-fill" style="width:${pct}%;background:${color}"></span></span>`;
  }

  function renderInsights(a) {
    if (!panel || !a) return;
    const body = panel.querySelector(".odc-body");
    const autoLabel = panel.querySelector(".odc-auto-label");
    autoLabel.textContent = `updates every ${autoRefreshSeconds}s`;

    // Status dot — green when live data
    const statusDot = panel.querySelector(".odc-status-dot");
    if (statusDot) statusDot.classList.add("odc-status-live");

    // Header price
    const priceEl = panel.querySelector(".odc-price-value");
    const statusEl = panel.querySelector(".odc-price-status");
    priceEl.textContent = a.price;
    priceEl.classList.remove("odc-dim");
    statusEl.textContent = (a.priceIsManual ? "Manual" : "Nearest strike") + " \u00B7 " + a.timestamp;

    // Attributes
    const attrsHTML = a.attributes.map((attr) =>
      `<div class="odc-attr-row">
        <div class="odc-attr-left">
          <span class="odc-attr-value">${attr.value}</span>
          <span class="odc-attr-label">${attr.label}</span>
        </div>
        <span class="odc-attr-dot odc-dot-${attr.color}"></span>
      </div>`
    ).join("");

    // Levels
    const supportHTML = a.supportZones.length
      ? a.supportZones.map((z, i) =>
          `<div class="odc-level odc-support">
            <span class="odc-level-label">${i === 0 ? "Support" : "Support " + (i + 1)}</span>
            <span class="odc-level-value">${z.label}</span>
            <span class="odc-level-strength">${strengthBar(z.strength)}</span>
          </div>`).join("")
      : `<div class="odc-level odc-dim">No clear support in range</div>`;

    const resistanceHTML = a.resistanceZones.length
      ? a.resistanceZones.map((z, i) =>
          `<div class="odc-level odc-resistance">
            <span class="odc-level-label">${i === 0 ? "Resistance" : "Resistance " + (i + 1)}</span>
            <span class="odc-level-value">${z.label}</span>
            <span class="odc-level-strength">${strengthBar(z.strength)}</span>
          </div>`).join("")
      : `<div class="odc-level odc-dim">No clear resistance in range</div>`;

    const magnetHTML = a.magnetStrike
      ? `<div class="odc-level odc-magnet"><span class="odc-level-label">Magnet</span><span class="odc-level-value">${a.magnetStrike.strike}</span></div>` : "";
    const triggerHTML = a.triggerLevel
      ? `<div class="odc-level odc-trigger"><span class="odc-level-label">Flip level</span><span class="odc-level-value">${a.triggerLevel}</span><span class="odc-level-note">behavior changes here</span></div>` : "";

    const changesHTML = a.changes.map((c) => `<div class="odc-change-item">\u203A ${c}</div>`).join("");

    body.innerHTML = `
      <div class="odc-section odc-env-section">
        <div class="odc-section-header">Current Gamma Environment</div>
        <p class="odc-env-summary">${a.summary}</p>
        <div class="odc-attrs">${attrsHTML}</div>
      </div>

      <div class="odc-section odc-levels-section">
        <div class="odc-section-header">Key Levels</div>
        ${resistanceHTML}${supportHTML}${magnetHTML}${triggerHTML}
      </div>

      <div class="odc-section odc-guidance-section">
        <div class="odc-section-header">Guidance</div>
        ${a.guidanceLines.map((g) => `<div class="odc-guidance-item odc-guidance-${g.type}">${g.text}</div>`).join("")}
      </div>

      <div class="odc-section odc-scenarios-section">
        <div class="odc-section-header">Scenarios</div>
        ${a.holdScenario ? `<div class="odc-scenario odc-scenario-hold">${a.holdScenario}</div>` : ""}
        ${a.breakScenario ? `<div class="odc-scenario odc-scenario-break">${a.breakScenario}</div>` : ""}
        ${a.ceilingScenario ? `<div class="odc-scenario odc-scenario-ceiling">${a.ceilingScenario}</div>` : ""}
      </div>

      <div class="odc-section odc-changes-section">
        <div class="odc-section-header">Recent Changes</div>
        ${changesHTML}
      </div>
    `;
  }

  // ================================================================
  //  REFRESH & INIT
  // ================================================================

  function refreshNow() {
    const data = extractDepthTable();
    if (!data) {
      if (panel) {
        panel.querySelector(".odc-body").innerHTML = `<div class="odc-loading">Waiting for Depth View Table\u2026<br/><span class="odc-dim">Make sure Depth View is visible.</span></div>`;
      }
      return;
    }
    const result = analyze(data);
    if (result) renderInsights(result);
  }

  function startAutoRefresh() {
    if (refreshTimer) clearInterval(refreshTimer);
    refreshTimer = setInterval(refreshNow, autoRefreshSeconds * 1000);
  }

  function enableDrag() {
    const header = panel.querySelector(".odc-header");
    let isDragging = false, startX, startY, startRight, startTop;
    header.addEventListener("mousedown", (e) => {
      if (e.target.closest(".odc-btn")) return;
      isDragging = true; startX = e.clientX; startY = e.clientY;
      const rect = panel.getBoundingClientRect();
      startRight = window.innerWidth - rect.right; startTop = rect.top;
      e.preventDefault();
    });
    document.addEventListener("mousemove", (e) => {
      if (!isDragging) return;
      panel.style.right = Math.max(0, startRight - (e.clientX - startX)) + "px";
      panel.style.top = Math.max(0, startTop + (e.clientY - startY)) + "px";
    });
    document.addEventListener("mouseup", () => { isDragging = false; });
  }

  function init() {
    setTimeout(() => { createPanel(); enableDrag(); refreshNow(); startAutoRefresh(); }, 2000);
  }

  let lastUrl = location.href;
  const observer = new MutationObserver(() => {
    if (location.href !== lastUrl) {
      lastUrl = location.href;
      setTimeout(() => { if (!document.getElementById(PANEL_ID)) init(); }, 2000);
    }
  });
  observer.observe(document.body, { childList: true, subtree: true });

  if (document.readyState === "complete") init();
  else window.addEventListener("load", init);
})();
